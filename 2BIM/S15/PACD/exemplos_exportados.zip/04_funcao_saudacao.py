def saudacao(nome):
    return f"Olá, {nome}!"

mensagem = saudacao("João")
print(mensagem)
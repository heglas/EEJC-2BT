pessoa = {'nome': 'Ana', 'idade': 25, 'cidade': 'São Paulo'}
idade_da_pessoa = pessoa['idade']
print(idade_da_pessoa)

pessoa['cidade'] = 'Rio de Janeiro'
print(pessoa)
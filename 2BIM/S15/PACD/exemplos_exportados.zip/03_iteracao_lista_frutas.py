frutas = ["maçã", "banana", "laranja"]
for fruta in frutas:
    print(fruta)
coordenadas = (3, 4)
x, y = coordenadas
print(f"Coordenadas: x={x}, y={y}")
numeros = [1, 2, 3, 4, 5]

terceiro_numero = numeros[2]
print(terceiro_numero)

numeros[1] = 10
print(numeros)
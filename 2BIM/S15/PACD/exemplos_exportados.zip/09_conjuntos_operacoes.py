cores_primarias = {'vermelho', 'azul', 'amarelo'}
cores_primarias.add('verde')
print(cores_primarias)

cores_primarias.remove('azul')
print(cores_primarias)
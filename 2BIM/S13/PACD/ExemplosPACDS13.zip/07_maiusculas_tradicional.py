palavras = ['python', 'é', 'incrível']
maiusculas = []
for palavra in palavras:
    maiusculas.append(palavra.upper())
print(maiusculas)
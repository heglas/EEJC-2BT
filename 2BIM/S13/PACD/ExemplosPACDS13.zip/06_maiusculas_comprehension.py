palavras = ['python', 'é', 'incrível']
maiusculas = [palavra.upper() for palavra in palavras]
print(maiusculas)
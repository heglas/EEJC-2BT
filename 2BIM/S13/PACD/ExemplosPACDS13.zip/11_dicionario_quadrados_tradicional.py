quadrados_dict = {}
for x in range(1, 6):
    quadrados_dict[x] = x**2
print(quadrados_dict)
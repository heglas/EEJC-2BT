par_impar = {x: 'par' if x % 2 == 0 else 'ímpar' for x in range(1, 21)}
print(par_impar)
numeros_pares = []
for x in range(10):
    if x % 2 == 0:
        numeros_pares.append(x)
print(numeros_pares)
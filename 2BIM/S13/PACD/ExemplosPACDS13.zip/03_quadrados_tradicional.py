quadrados = []
for x in range(1, 6):
    quadrados.append(x**2)
print(quadrados)
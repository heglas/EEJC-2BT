coordenadas = (2, 3)
# coordenadas[0] = 1  # Isso gera TypeError
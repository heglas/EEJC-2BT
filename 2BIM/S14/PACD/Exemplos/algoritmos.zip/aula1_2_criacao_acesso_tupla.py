minha_tupla = (1, "Olá", 3.14, True)
coordenadas = (2, 3)
x = coordenadas[0]
y = coordenadas[1]
print(x)
print(y)
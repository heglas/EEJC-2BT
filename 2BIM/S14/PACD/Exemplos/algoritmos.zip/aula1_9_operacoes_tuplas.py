minha_tupla = (10, 20, 30)
nova_tupla = minha_tupla + (4, 5, 6)
repetida = minha_tupla * 2
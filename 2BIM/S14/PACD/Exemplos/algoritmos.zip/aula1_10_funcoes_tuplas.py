minha_tupla = (10, 20, 30)
tamanho = len(minha_tupla)
# indice = minha_tupla.index('texto')
# ocorrencias = minha_tupla.count(2)
string = "abc"
tupla_a_partir_string = tuple(string)
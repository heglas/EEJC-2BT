minha_tupla = ((1,2,3), 1, [1,4,'sim'], True)
print(type(minha_tupla))
print(type(minha_tupla[0]))
print(type(minha_tupla[2]))

tupla_aninhada = ((1, 2, 3), ('a', 'b', 'c'), (True, False, True))
print(tupla_aninhada[0])
print(tupla_aninhada[1][1])
print(tupla_aninhada[2][2])
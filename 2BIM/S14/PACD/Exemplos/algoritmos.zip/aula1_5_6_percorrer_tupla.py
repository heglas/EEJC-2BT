minha_tupla = (1, 2.9, 'palavra', True)
for elemento in minha_tupla:
    print(elemento)

minha_tupla = (10, 20, 30, 40, 50)
for indice, elemento in enumerate(minha_tupla):
    print(f"Índice: {indice}, Elemento: {elemento}")
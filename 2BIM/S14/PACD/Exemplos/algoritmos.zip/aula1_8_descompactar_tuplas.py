minha_tupla = (10, 20, 30)
a, b, c = minha_tupla
print("a:", a)
print("b:", b)
print("c:", c)

minha_outra_tupla = (1, 2.9, 'palavra', True, 'sim', 2)
var1, var2, var3, var4, _, _ = minha_outra_tupla
print(var1, var2, var3, var4)
# Questão 43
# Classifica as temperaturas em categorias

temperaturas = [-5, 0, 10, 16, 25, 32]

for temp in temperaturas:
    if temp <= 0:
        print("PERIGO")
    elif temp < 15:
        print("FRIO")
    elif temp <= 30:
        print("AGRADÁVEL")
    else:
        print("CALOR")

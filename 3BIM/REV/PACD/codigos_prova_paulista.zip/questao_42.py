# Questão 42
# Retorna o preço final aplicando o desconto

def calcular_preco(preco, desconto):
    preco_final = preco - (preco * desconto / 100)
    return preco_final

# Exemplo de uso
preco_original = 100
desconto_percentual = 10
print("Preço com desconto:", calcular_preco(preco_original, desconto_percentual))

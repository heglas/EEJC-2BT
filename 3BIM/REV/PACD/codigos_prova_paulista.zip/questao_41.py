# Questão 41
# Atualiza o valor de "Metrô" para 14

transporte = {
    "Ônibus": 15,
    "Carro": 10,
    "Bicicleta": 5,
    "Metrô": 12
}

# Correta
transporte["Metrô"] = 14

print(transporte)
